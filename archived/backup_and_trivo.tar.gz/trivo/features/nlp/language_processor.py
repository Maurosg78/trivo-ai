"""
Procesador de lenguaje natural avanzado para interpretar recetas a partir de descripciones.
Utiliza NLTK para procesamiento básico y sentence-transformers para mejor comprensión contextual.
"""

import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import re
import os
import json
from sentence_transformers import SentenceTransformer, util
import logging

# Configurar logging
logger = logging.getLogger('trivo.nlp')

# Asegurar que los recursos necesarios están disponibles
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt', quiet=True)
    
try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords', quiet=True)

class LanguageProcessor:
    """
    Procesador de lenguaje natural avanzado para recetas.
    Combina enfoques basados en reglas y modelos de embeddings para una mejor comprensión.
    """
    
    def __init__(self, use_transformers=True):
        """
        Inicializa el procesador de lenguaje natural.
        
        Args:
            use_transformers: Si se deben usar modelos de embeddings más avanzados
        """
        # Cargar modelo de embeddings si está habilitado
        self.use_transformers = use_transformers
        if use_transformers:
            try:
                self.model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')
                logger.info("Modelo de embeddings cargado correctamente.")
            except Exception as e:
                logger.warning(f"No se pudo cargar el modelo de embeddings: {e}")
                self.use_transformers = False
        
        # Stopwords en español
        self.stopwords = set(stopwords.words('spanish'))
        
        # Características ampliadas de masas
        self.keywords = {
            # Tipos de pizza
            "pizza_types": [
                "margarita", "napolitana", "pepperoni", "hawaiana", "vegana", "cuatro quesos", 
                "barbacoa", "marinera", "caprichosa", "siciliana", "española", "mexicana", 
                "carbonara", "fugazzeta", "fugazza", "calzone", "neoyorquina", "chicago", "detroit"
            ],
            
            # Tipos de masa
            "dough_types": {
                "pizza": [
                    "delgada", "gruesa", "crujiente", "suave", "integral", "artesanal", "tradicional", 
                    "nueva york", "estilo chicago", "madre", "fermentación natural", "hidratación alta",
                    "de poolish", "biga", "napolitana auténtica", "romana", "siciliana", "detroit"
                ],
                "pan": [
                    "baguette", "hogaza", "chapata", "de molde", "integral", "multicereales", "de centeno",
                    "campesino", "de masa madre", "brioche", "focaccia", "naan", "pita"
                ],
                "pastelería": [
                    "hojaldre", "quebrada", "sablée", "brisa", "choux", "masa para galletas", 
                    "croissant", "danesa", "strudel"
                ]
            },
            
            # Tamaños
            "sizes": ["personal", "mediana", "familiar", "industrial", "grande", "pequeña", "individual", "extra grande"],
            
            # Restricciones dietéticas
            "restrictions": [
                "sin gluten", "vegana", "keto", "baja en sodio", "sin lácteos", "sin huevo", "sin azúcar",
                "baja en carbohidratos", "baja en grasas", "sin aditivos", "sin conservantes", "ecológica",
                "sin transgénicos", "paleo", "diabética"
            ],
            
            # Colores
            "colors": ["blanca", "roja", "verde", "integral", "negra", "dorada", "violeta", "amarilla", "multicolor"],
            
            # Métodos de cocción
            "cooking_methods": [
                "horno de leña", "horno eléctrico", "sartén", "plancha", "parrilla", "horno de piedra",
                "horno doméstico", "horno profesional", "microondas", "freidora de aire", "sous vide"
            ],
            
            # Tiempo de fermentación
            "fermentation_times": [
                "rápida", "lenta", "24 horas", "48 horas", "72 horas", "larga", "corta", "express",
                "overnight", "fermentación en frío", "tradicional"
            ],
            
            # Propiedades de textura
            "texture_properties": [
                "crujiente", "suave", "elástica", "alveolada", "aireada", "compacta", "ligera", "densa",
                "esponjosa", "húmeda", "seca", "masticable", "chiclosa", "con corteza", "sin corteza"
            ],
            
            # Tipos de producto (amplía el alcance)
            "product_types": ["pizza", "pan", "galletas", "pastelería", "pasta", "empanadas", "tortillas", "crepes", "gofres"]
        }
        
        # Palabras clave para sin gluten y propiedades
        self.gluten_free_keywords = [
            "sin gluten", "gluten free", "celíaco", "celiaco", "celíaca", "celiaca", 
            "intolerancia al gluten", "sensibilidad al gluten", "libre de gluten",
            "apto para celíacos"
        ]
        
        self.gluten_free_properties = {
            "elasticidad": ["elástica", "elástico", "que se estire", "flexible", "maleable"],
            "crujiente": ["crujiente", "crocante", "crunch", "con corteza dura", "corteza crujiente"],
            "suave": ["suave", "tierna", "tierno", "blanda", "blando", "esponjosa", "esponjoso"],
            "ligera": ["ligera", "ligero", "liviana", "liviano", "no pesada", "fácil de digerir"]
        }
        
        # Base de conocimiento ampliada para ingredientes y propiedades
        self.ingredient_properties = {
            "harina_de_arroz": {
                "descripción": "Harina básica sin gluten, sabor neutro",
                "hidratación": 0.65,
                "elasticidad": 0.3,
                "textura": "suave",
                "sustitutos": ["harina de sorgo", "harina de mijo"],
                "proporción_base": 0.6
            },
            "harina_de_almendra": {
                "descripción": "Harina sin gluten rica en proteínas y grasas",
                "hidratación": 0.3,
                "elasticidad": 0.2,
                "textura": "densa",
                "sustitutos": ["harina de avellana", "harina de coco"],
                "proporción_base": 0.15
            },
            "almidón_de_maíz": {
                "descripción": "Almidón para mejorar textura en masas sin gluten",
                "hidratación": 0.7,
                "elasticidad": 0.1,
                "textura": "ligera",
                "sustitutos": ["fécula de patata", "tapioca"],
                "proporción_base": 0.25
            },
            "goma_xantana": {
                "descripción": "Espesante que proporciona elasticidad a masas sin gluten",
                "hidratación": 0,
                "elasticidad": 0.9,
                "textura": "elástica",
                "sustitutos": ["psyllium husk", "goma guar"],
                "proporción_base": 0.02
            }
        }
        
        # Proporciones e hidratación por tipo de producto
        self.product_specifications = {
            "pizza": {
                "napolitana": {"hidratación": 0.65, "levadura": 0.01, "sal": 0.025, "aceite": 0.03},
                "nueva york": {"hidratación": 0.60, "levadura": 0.008, "sal": 0.02, "aceite": 0.02},
                "chicago": {"hidratación": 0.55, "levadura": 0.015, "sal": 0.02, "aceite": 0.05},
                "default": {"hidratación": 0.62, "levadura": 0.01, "sal": 0.022, "aceite": 0.03}
            },
            "pan": {
                "baguette": {"hidratación": 0.72, "levadura": 0.005, "sal": 0.018, "aceite": 0},
                "chapata": {"hidratación": 0.8, "levadura": 0.003, "sal": 0.02, "aceite": 0.02},
                "default": {"hidratación": 0.7, "levadura": 0.01, "sal": 0.02, "aceite": 0.01}
            },
            "default": {"hidratación": 0.65, "levadura": 0.01, "sal": 0.02, "aceite": 0.02}
        }
        
        # Cargar frases de ejemplo para embeddings si está disponible
        self.reference_sentences = {}
        if self.use_transformers:
            self._load_reference_sentences()
    
    def _load_reference_sentences(self):
        """Carga frases de referencia para cada categoría"""
        categories = {
            "masa_pizza": [
                "Quiero hacer una pizza",
                "Necesito una receta para pizza",
                "Cómo hago masa de pizza",
                "Dame una receta de pizza"
            ],
            "masa_pan": [
                "Quiero hacer pan",
                "Necesito una receta para pan",
                "Cómo hago masa de pan",
                "Dame una receta de pan"
            ],
            "sin_gluten": [
                "Necesito algo sin gluten",
                "Soy celíaco",
                "No puedo comer gluten",
                "Receta apta para celíacos"
            ],
            "fermentación_larga": [
                "Quiero una masa con fermentación larga",
                "Prefiero fermentación de 24 horas",
                "Me gusta la masa fermentada lentamente",
                "Masa con fermentación en frío"
            ]
        }
        
        # Crear embeddings para las frases de referencia
        if self.use_transformers:
            self.reference_embeddings = {}
            for category, sentences in categories.items():
                try:
                    self.reference_embeddings[category] = self.model.encode(sentences)
                except Exception as e:
                    logger.warning(f"Error al codificar categoría {category}: {e}")
    
    def process_request(self, text):
        """
        Procesa una solicitud en lenguaje natural con análisis avanzado.
        
        Args:
            text: Texto de la solicitud
            
        Returns:
            Diccionario con las propiedades detectadas y la receta generada
        """
        logger.info(f"Procesando solicitud: {text}")
        
        # Normalizar y tokenizar texto
        text = text.lower()
        tokens = word_tokenize(text, language='spanish')
        tokens = [t for t in tokens if t not in self.stopwords]
        
        # Detector avanzado de propiedades
        properties = self._detect_properties(text, tokens)
        
        # Realizar análisis mediante embeddings si está disponible
        if self.use_transformers:
            self._enhance_with_embeddings(text, properties)
        
        # Inferir propiedades faltantes basadas en conocimiento del dominio
        self._infer_missing_properties(properties)
        
        # Generar una receta adaptada a las propiedades
        recipe = self._generate_recipe(properties)
        
        # Registrar resultado
        logger.info(f"Propiedades detectadas: {properties}")
        
        return {
            "properties": properties,
            "recipe": recipe,
            "status": "success"
        }
    
    def _detect_properties(self, text, tokens):
        """Detecta propiedades básicas utilizando keywords y reglas"""
        # Inicializar propiedades
        properties = {
            "product_type": self._detect_product_type(text),
            "pizza_type": self._find_match(text, self.keywords["pizza_types"]),
            "dough_type": None,  # Se establecerá según el tipo de producto
            "size": self._find_match(text, self.keywords["sizes"], default="mediana"),
            "restrictions": [r for r in self.keywords["restrictions"] if r in text],
            "color": self._find_match(text, self.keywords["colors"]),
            "cooking_method": self._find_match(text, self.keywords["cooking_methods"]),
            "fermentation": self._find_match(text, self.keywords["fermentation_times"]),
            "texture": [t for t in self.keywords["texture_properties"] if t in text]
        }
        
        # Establecer tipo de masa según el tipo de producto
        product = properties["product_type"] or "pizza"
        if product in self.keywords["dough_types"]:
            properties["dough_type"] = self._find_match(text, self.keywords["dough_types"][product])
        
        # Detectar si es sin gluten con más profundidad
        is_gluten_free = any(keyword in text for keyword in self.gluten_free_keywords)
        if is_gluten_free and "sin gluten" not in properties["restrictions"]:
            properties["restrictions"].append("sin gluten")
        
        # Detectar propiedades deseadas para masas sin gluten
        if "sin gluten" in properties["restrictions"]:
            gluten_free_desired_properties = {}
            for prop, keywords in self.gluten_free_properties.items():
                if any(keyword in text for keyword in keywords):
                    gluten_free_desired_properties[prop] = True
            
            if gluten_free_desired_properties:
                properties["gluten_free_properties"] = gluten_free_desired_properties
        
        return properties
    
    def _detect_product_type(self, text):
        """Detecta el tipo de producto principal (pizza, pan, etc.)"""
        for product in self.keywords["product_types"]:
            if product in text:
                return product
        # Devolver "pizza" como default si no se especifica
        return "pizza"
    
    def _find_match(self, text, options, default=None):
        """Encuentra coincidencias entre el texto y las opciones"""
        for option in options:
            if option in text:
                return option
        return default
    
    def _enhance_with_embeddings(self, text, properties):
        """Mejora la detección mediante embeddings semánticos"""
        if not self.use_transformers:
            return
        
        try:
            # Obtener embedding del texto de usuario
            query_embedding = self.model.encode(text)
            
            # Comparar con categorías de referencia
            for category, embeddings in self.reference_embeddings.items():
                # Calcular similitud coseno con cada frase de referencia
                similarities = util.cos_sim(query_embedding, embeddings)
                max_similarity = float(similarities.max())
                
                # Si la similitud es alta, aplicar la categoría
                if max_similarity > 0.6:  # Umbral de similitud
                    if category == "masa_pizza" and not properties["product_type"]:
                        properties["product_type"] = "pizza"
                    elif category == "masa_pan" and not properties["product_type"]:
                        properties["product_type"] = "pan"
                    elif category == "sin_gluten" and "sin gluten" not in properties["restrictions"]:
                        properties["restrictions"].append("sin gluten")
                    elif category == "fermentación_larga" and not properties["fermentation"]:
                        properties["fermentation"] = "lenta"
        
        except Exception as e:
            logger.warning(f"Error en análisis de embeddings: {e}")
    
    def _infer_missing_properties(self, properties):
        """Infiere propiedades faltantes basadas en otras propiedades y conocimiento del dominio"""
        # Inferir tipo de pizza si no está explícito
        if properties["product_type"] == "pizza" and not properties["pizza_type"]:
            # Si tiene restricciones, sugerir un tipo compatible
            if "vegana" in properties["restrictions"]:
                properties["pizza_type"] = "vegana"
            elif "sin lácteos" in properties["restrictions"]:
                properties["pizza_type"] = "marinera"  # Sin queso
        
        # Inferir propiedades de textura según fermentación
        if properties["fermentation"] in ["lenta", "24 horas", "48 horas", "72 horas"] and not properties["texture"]:
            properties["texture"] = ["alveolada", "ligera"]
        
        # Inferir método de cocción según tipo de producto
        if not properties["cooking_method"]:
            if properties["product_type"] == "pizza":
                properties["cooking_method"] = "horno doméstico"
            elif properties["product_type"] == "pan":
                properties["cooking_method"] = "horno doméstico"
    
    def _generate_recipe(self, properties):
        """
        Genera una receta avanzada basada en las propiedades detectadas.
        
        Args:
            properties: Diccionario con propiedades detectadas
            
        Returns:
            Diccionario con la receta generada
        """
        # Determinar el tipo de producto para nombre adecuado
        product_type = properties["product_type"] or "pizza"
        dough_type = properties["dough_type"] or "clásica"
        
        # Nombre de la receta
        if product_type == "pizza":
            pizza_type = properties["pizza_type"] or "básica"
            recipe_name = f"Masa para pizza {pizza_type} {dough_type}"
        else:
            recipe_name = f"Masa para {product_type} {dough_type}"
        
        recipe = {
            "name": recipe_name,
            "ingredients": {},
            "instructions": []
        }
        
        # Determinar cantidades base según especificaciones
        specs = self._get_product_specifications(properties)
        
        # Cantidades base
        base_flour = 1000  # g
        
        # Calcular ingredientes según especificaciones
        water = int(base_flour * specs["hidratación"])
        salt = int(base_flour * specs["sal"])
        yeast = int(base_flour * specs["levadura"])
        oil = int(base_flour * specs["aceite"])
        
        # Ajustar ingredientes según restricciones
        if "sin gluten" in properties["restrictions"]:
            # Base para masa sin gluten
            recipe["ingredients"] = self._generate_gluten_free_recipe(properties, base_flour)
        else:
            # Receta estándar con harina
            recipe["ingredients"]["harina"] = base_flour  # g
            
            # Personalizaciones según tipo de dough
            if properties["dough_type"] == "integral":
                recipe["ingredients"] = {
                    "harina integral": int(base_flour * 0.7),
                    "harina": int(base_flour * 0.3)
                }
            elif properties["dough_type"] == "multicereales":
                recipe["ingredients"] = {
                    "harina": int(base_flour * 0.7),
                    "mezcla de semillas": int(base_flour * 0.2),
                    "salvado": int(base_flour * 0.1)
                }
        
        # Agregar ingredientes básicos
        recipe["ingredients"]["agua"] = water
        recipe["ingredients"]["sal"] = salt
        recipe["ingredients"]["levadura"] = yeast
        recipe["ingredients"]["aceite de oliva"] = oil
        
        # Ajustes por color si es necesario
        if properties["color"]:
            recipe = self._add_color_ingredients(recipe, properties["color"])
        
        # Generar instrucciones adaptadas
        recipe["instructions"] = self._generate_instructions(properties)
        
        return recipe
    
    def _get_product_specifications(self, properties):
        """Obtiene especificaciones para el tipo de producto y variante"""
        product = properties["product_type"] or "default"
        subtype = None
        
        if product == "pizza":
            subtype = properties["pizza_type"] if properties["pizza_type"] in self.product_specifications["pizza"] else "default"
        elif product == "pan":
            subtype = properties["dough_type"] if properties["dough_type"] in self.product_specifications["pan"] else "default"
        
        if product in self.product_specifications:
            if subtype and subtype in self.product_specifications[product]:
                return self.product_specifications[product][subtype]
            return self.product_specifications[product]["default"]
        
        return self.product_specifications["default"]
    
    def _generate_gluten_free_recipe(self, properties, base_flour):
        """Genera una receta específica sin gluten"""
        gf_ingredients = {}
        
        # Propiedades deseadas
            if "gluten_free_properties" in properties:
                gf_props = properties["gluten_free_properties"]
                
                if gf_props.get("elasticidad"):
                    # Más goma xantana para elasticidad
                gf_ingredients = {
                    "harina de arroz": int(base_flour * 0.6),
                    "almidón de maíz": int(base_flour * 0.3),
                    "harina de almendra": int(base_flour * 0.1),
                    "goma xantana": int(base_flour * 0.025)
                    }
                elif gf_props.get("crujiente"):
                    # Más almidón para crujiente
                gf_ingredients = {
                    "harina de arroz": int(base_flour * 0.5),
                    "almidón de maíz": int(base_flour * 0.4),
                    "fécula de patata": int(base_flour * 0.1),
                    "goma xantana": int(base_flour * 0.015)
                    }
                elif gf_props.get("suave"):
                    # Más variedad de harinas para suavidad
                gf_ingredients = {
                    "harina de arroz": int(base_flour * 0.4),
                    "almidón de maíz": int(base_flour * 0.25),
                    "harina de mijo": int(base_flour * 0.15),
                    "almidón de patata": int(base_flour * 0.2),
                    "goma xantana": int(base_flour * 0.018)
                    }
                elif gf_props.get("ligera"):
                    # Más proteína para estructura más ligera
                gf_ingredients = {
                    "harina de arroz": int(base_flour * 0.55),
                    "almidón de maíz": int(base_flour * 0.25),
                    "harina de quinoa": int(base_flour * 0.15),
                    "psyllium husk": int(base_flour * 0.05),
                    "goma xantana": int(base_flour * 0.015)
                    }
                else:
                    # Receta equilibrada sin propiedades específicas
                gf_ingredients = {
                    "harina de arroz": int(base_flour * 0.65),
                    "almidón de maíz": int(base_flour * 0.3),
                    "harina de garbanzo": int(base_flour * 0.05),
                    "goma xantana": int(base_flour * 0.02)
                    }
            else:
                # Receta por defecto sin gluten
            gf_ingredients = {
                "harina de arroz": int(base_flour * 0.7),
                "almidón de maíz": int(base_flour * 0.3),
                "goma xantana": int(base_flour * 0.02)
            }
        
        return gf_ingredients
    
    def _add_color_ingredients(self, recipe, color):
        """Añade ingredientes para dar color natural a la masa"""
        if color == "rojo":
            recipe["ingredients"]["remolacha en polvo"] = 20  # g
        elif color == "verde":
            recipe["ingredients"]["espinaca en polvo"] = 20  # g
        elif color == "negro":
            recipe["ingredients"]["carbón activado"] = 10  # g
        elif color == "dorada":
            recipe["ingredients"]["cúrcuma"] = 8  # g
        elif color == "violeta":
            recipe["ingredients"]["polvo de arándanos"] = 15  # g
        
        return recipe
    
    def _generate_instructions(self, properties):
        """Genera instrucciones adaptadas al tipo de masa y propiedades"""
        is_gluten_free = "sin gluten" in properties["restrictions"]
        product_type = properties["product_type"] or "pizza"
        fermentation = properties["fermentation"]
        
        instructions = []
        
        # Paso 1: Preparación de ingredientes
        instructions.append(
            "Pesa y prepara todos los ingredientes secos y líquidos por separado. "
            "Asegúrate de que los ingredientes estén a temperatura ambiente."
        )
        
        # Paso 2: Preparación de levadura
        if "levadura" in properties:
            instructions.append(
                "En un recipiente pequeño, disuelve la levadura en 50 ml de agua tibia (35°C). "
                "Deja reposar por 5-10 minutos hasta que se forme espuma."
            )
        
        # Paso 3: Mezclado
        if is_gluten_free:
            instructions.append(
                "Mezcla todos los ingredientes secos en un recipiente amplio. "
                "Realiza este paso minuciosamente para garantizar una distribución uniforme "
                "de la goma xantana u otros aglutinantes."
            )
        else:
            instructions.append(
                "En un recipiente grande, mezcla la harina con la sal. "
                "Forma un volcán en el centro para añadir los ingredientes líquidos."
            )
        
        # Paso 4: Formación de masa
        if is_gluten_free:
            instructions.append(
                "Añade gradualmente el agua con levadura y el aceite a la mezcla de harinas. "
                "Mezcla primero con una cuchara y luego con las manos hasta integrar todos los ingredientes. "
                "La masa sin gluten será más pegajosa que una tradicional, esto es normal."
            )
        else:
            instructions.append(
                "Vierte la mezcla de levadura y agua en el centro del volcán. "
                "Incorpora el aceite de oliva y comienza a mezclar desde el centro "
                "hacia afuera, integrando gradualmente la harina."
            )
        
        # Paso 5: Amasado
        if is_gluten_free:
            instructions.append(
                "Amasa suavemente durante 5-7 minutos. No sobreamases las masas sin gluten "
                "para evitar que se vuelvan demasiado compactas. "
                "Usa las manos ligeramente humedecidas si la masa se pega demasiado."
            )
        else:
            instructions.append(
                "Transfiere la masa a una superficie ligeramente enharinada. "
                "Amasa enérgicamente durante 10-12 minutos hasta obtener una masa elástica y lisa. "
                "Para comprobar el punto óptimo, estira un pequeño trozo de masa - debe formar una "
                "fina membrana translúcida sin romperse (prueba de la ventana)."
            )
        
        # Paso 6: Primera fermentación
        if fermentation in ["lenta", "24 horas", "48 horas", "72 horas", "fermentación en frío"]:
            fermentation_time = {
                "lenta": "12-18 horas",
                "24 horas": "24 horas",
                "48 horas": "48 horas",
                "72 horas": "72 horas",
                "fermentación en frío": "24-72 horas"
            }.get(fermentation, "24 horas")
            
            instructions.append(
                f"Forma una bola con la masa y colócala en un recipiente ligeramente aceitado. "
                f"Cúbrela con film transparente y refrigera durante {fermentation_time}. "
                f"Este proceso de fermentación lenta desarrollará sabores complejos y mejorará la digestibilidad."
            )
        else:
            fermentation_time = "1-2 horas" if not is_gluten_free else "45-60 minutos"
            
            instructions.append(
                f"Forma una bola con la masa y colócala en un recipiente ligeramente aceitado. "
                f"Cúbrela con un paño húmedo y deja fermentar en un lugar cálido durante {fermentation_time} "
                f"hasta que duplique su tamaño."
            )
        
        # Paso 7: División y formado según tipo de producto
        if product_type == "pizza":
            portions = "4 porciones iguales" if properties["size"] in ["familiar", "grande"] else "2 porciones iguales"
            
            instructions.append(
                f"Desgasifica la masa presionando suavemente y divídela en {portions}. "
                f"Forma bolas suaves y déjalas reposar cubiertas durante 15-30 minutos."
            )
            
            instructions.append(
                "Estira cada porción de masa sobre una superficie ligeramente enharinada "
                "formando discos del grosor deseado. Para masas napolitanas, deja el borde más "
                "grueso para formar el característico cornicione."
            )
        elif product_type == "pan":
            instructions.append(
                "Desgasifica suavemente la masa y dale la forma deseada según el tipo de pan. "
                "Colócala sobre papel de hornear o en el molde correspondiente."
            )
            
            instructions.append(
                "Deja reposar la masa formada durante 30-45 minutos para una segunda fermentación. "
                "Cubre con un paño húmedo para evitar que se reseque la superficie."
            )
        
        # Paso 8: Preparación para horneado
        if product_type == "pizza":
            instructions.append(
                "Precalienta el horno a la máxima temperatura (idealmente 250-300°C) "
                "durante al menos 30 minutos con la piedra o bandeja dentro."
            )
        elif product_type == "pan":
            instructions.append(
                "Precalienta el horno a 220°C. Para obtener corteza crujiente, "
                "coloca un recipiente pequeño con agua en la parte inferior del horno "
                "para generar vapor."
            )
        
        # Paso 9: Horneado
        if product_type == "pizza":
            instructions.append(
                "Transfiere la masa estirada al horno y hornea durante 3-5 minutos "
                "para precocer la base. Retira, añade los ingredientes deseados y "
                "hornea 5-7 minutos más hasta que el queso burbujee y los bordes estén dorados."
            )
        elif product_type == "pan":
            instructions.append(
                "Antes de hornear, realiza cortes superficiales decorativos en la "
                "superficie con un cuchillo afilado. Hornea durante 25-35 minutos "
                "hasta que la corteza esté dorada y al golpear la base suene hueca."
            )
        
        # Paso 10: Enfriamiento y conservación
        if product_type == "pizza":
            instructions.append(
                "Deja reposar la pizza terminada durante 1-2 minutos antes de cortar, "
                "para que los ingredientes se asienten y sea más fácil servir."
            )
        elif product_type == "pan":
            instructions.append(
                "Retira el pan del horno y déjalo enfriar sobre una rejilla para evitar "
                "que la base se humedezca. Espera al menos 30 minutos antes de cortar "
                "para que termine de cocerse internamente."
            )
        
        return instructions